import os
import configparser
from azure.storage.blob import BlobServiceClient
import boto3


config = configparser.ConfigParser()
config.read('credentials.ini')


AZURE_CONNECTION_STRING = config['azure']['connection_string']
AZURE_CONTAINER_NAME = config['azure']['container_name']
BLOB_NAME = config['azure']['blob_name']

AWS_ACCESS_KEY_ID = config['aws']['access_key_id']
AWS_SECRET_ACCESS_KEY = config['aws']['secret_access_key']
AWS_S3_BUCKET_NAME = config['aws']['s3_bucket_name']


LOCAL_FILE_NAME = BLOB_NAME

def download_blob_from_azure():
    print("Downloading blob from Azure Blob Storage...")
    blob_service_client = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)
    blob_client = blob_service_client.get_blob_client(container=AZURE_CONTAINER_NAME, blob=BLOB_NAME)
    
    with open(LOCAL_FILE_NAME, "wb") as download_file:
        download_file.write(blob_client.download_blob().readall())

def upload_file_to_s3():
    print("Uploading file to AWS S3...")
    s3_client = boto3.client('s3', aws_access_key_id=AWS_ACCESS_KEY_ID, aws_secret_access_key=AWS_SECRET_ACCESS_KEY)
    s3_client.upload_file(LOCAL_FILE_NAME, AWS_S3_BUCKET_NAME, BLOB_NAME)

def delete_local_file():
    print("Deleting local file...")
    os.remove(LOCAL_FILE_NAME)

def main():
    download_blob_from_azure()
    upload_file_to_s3()
    delete_local_file()
    print("Process completed successfully.")

if __name__ == "__main__":
    main()
